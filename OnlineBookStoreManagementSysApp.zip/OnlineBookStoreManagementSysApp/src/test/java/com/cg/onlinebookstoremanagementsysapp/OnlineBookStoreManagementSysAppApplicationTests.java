package com.cg.onlinebookstoremanagementsysapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineBookStoreManagementSysAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
