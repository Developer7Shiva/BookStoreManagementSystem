/*package com.cg.onlinebookstoremanagementsysapp.controller;

import static org.hamcrest.CoreMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.cg.onlinebookstoremanagementsysapp.entity.Book;
import com.cg.onlinebookstoremanagementsysapp.exception.ResourceNotFoundException;
import com.cg.onlinebookstoremanagementsysapp.service.IAdminService;
import com.cg.onlinebookstoremanagementsysapp.service.IBookService;
import com.cg.onlinebookstoremanagementsysapp.service.IOrderDetailsService;
import com.cg.onlinebookstoremanagementsysapp.service.IOrderService;
import com.cg.onlinebookstoremanagementsysapp.service.IReaderService;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest
public class BookControllerTest {
	
	
	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private IAdminService adminService;
	@MockBean
	private IReaderService readerService;
	@MockBean
	private IBookService bookService;
	@MockBean
	private IOrderService orderService;
	@MockBean
	private IOrderDetailsService orderDetailsService;
	@Autowired
	 private ObjectMapper objectMapper;
	private Book book;
	private Optional<Book> book1;
	@BeforeEach
	public void init() {
	 book=new Book();
	 book1=Optional.of(new Book());
	}
	@Test
	 public void testSaveBook() throws Exception{
		 when(bookService.addBook((Book)any(Book.class))).thenReturn(book1);
		 }
	 @Test
	 public void testGetAllBook() {
		 	List<Book> bookList = new ArrayList<Book>();
			bookList.add(book);
			
			when(bookService.getAllBooks()).thenReturn(bookList);
	 }
	/* @Test
	 public void testgetBooksById()throws ResourceNotFoundException {
		 when(bookService.getBooksById(anyLong())).thenReturn(book1);
	    }
	 }*/



