package com.cg.onlinebookstoremanagementsysapp.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.onlinebookstoremanagementsysapp.entity.Book;

@Repository
public interface BookRepository  extends JpaRepository<Book, Long> {
	
	
	//list all books which are less than book price
	//select * from book where Author name= ?
	public List<Book> findByBookAuthorName(String bookAuthorName);

	//list all books which are less than book price
	//select * from book where Book  Category= ?
	public List<Book> findByBookCategory(String bookCategory);
	
	//select * from book where Book Title= ?
	public Book findByBookName(String bookName);
	
	public String findBookStatus(long bookId);
	


}
