package com.cg.onlinebookstoremanagementsysapp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.cg.onlinebookstoremanagementsysapp.service.BookService;
import com.cg.onlinebookstoremanagementsysapp.entity.Book;

	@RestController
	@RequestMapping("/api/v1/book")
	public class BookController {
		@Autowired
		private BookService bookService;
		
		
		@PostMapping
		public String saveBook(@RequestBody Book book) {
			try {
				Optional<Book> Vbook = bookService.addBook(book);
				if(Vbook.isPresent()) {
					return "The new Book Added Successfully";
				}else {
					return "Something went wrong during book Insertion";
				}
			} catch(Exception e) {
				return "Something Went Wrong during book Insertion";
			}
		}
		
		@GetMapping
		public List<Book> getAllBook(){
			return bookService.getAllBooks();
		}
		
		@GetMapping("/{book_id}")
		public Optional<Book> getBooksById(@PathVariable("book_id") long bookId){
			return bookService.getBooksById(bookId);
		}
		
		@PutMapping
		public String updateBook(@RequestBody Book book) {
			String Vbook = bookService.updateBookById(book);
			if(Vbook.isEmpty()) {
				return "The Given Information was wrong";
			}
				else {
					return "Book Updated Successfully";
				}

		}	
		@DeleteMapping("/Deactivate book/{book_id}")
		public String deleteBookById(@PathVariable("book_id") Long book_id) {
			String result = bookService.deleteBookById(book_id);
			return result;
		}
		
		
		@GetMapping("/findbookbyname/{bookname}")
		public Book findByBookName(@PathVariable("bookname") String bookName) {
			return bookService.findByBookName(bookName);
		}
		
		@GetMapping("/findbookbycategory/{bookcat}")
		public List<Book> findByBookCategory(@PathVariable("bookcat") String bookCategory) {
			return bookService.findByBookCategory(bookCategory);
		}
		
		@GetMapping("/findbookbyauthor/{bookau}")
		public List<Book> findByBookAuthorName(@PathVariable("bookau")  String bookAuthorName){
			return bookService.findByBookAuthorName(bookAuthorName);		
		}
		@GetMapping("/findbookstatus/{bookstatus}")
		public String findBookStatus(@PathVariable("bookstatus")  long bookId){
			return bookService.findBookStatus(bookId);		
		}
	}
