package com.cg.onlinebookstoremanagementsysapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineBookStoreManagementSysAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineBookStoreManagementSysAppApplication.class, args);
	}

}
