package com.cg.onlinebookstoremanagementsysapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.onlinebookstoremanagementsysapp.entity.Book;
import com.cg.onlinebookstoremanagementsysapp.repository.BookRepository;
@Service
public class BookService implements IBookService{

	@Autowired
	private BookRepository bookRepo;
	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return bookRepo.findAll();
	}

	@Override
	public Optional<Book> getBooksById(Long bookId) {
		// TODO Auto-generated method stub
		return bookRepo.findById(bookId);
	}

	@Override
	public Optional<Book> addBook(Book book) {
		if (bookRepo.existsById(book.getBookId())){
            return Optional.empty();
        }else{
            return Optional.of(bookRepo.save(book));
        }
	}

	@Override
	public String updateBookById(Book bookId) {
		if (bookRepo.existsById(bookId.getBookId())){
			Book adUp =bookRepo.save(bookId);
				if(adUp!=null)
					return "Book Updated Successfully";
	    }else{
	        return "Can't Update Book caused by Wrong information ";
	    }
		return "The Given Book was already Exits!";
	}

	@Override
	public String deleteBookById(long bookId) {
		if (bookRepo.existsById(bookId) && bookId!=0){
	        bookRepo.deleteById(bookId);
	        	return bookId + " deleted successfully!";
	    }else{
	        return "The data does not exist in records!";
	    }
	    
	}
	@Override
	public Book findByBookName(String bookName) {
		// TODO Auto-generated method stub
		return bookRepo.findByBookName(bookName);
	}
	@Override
	public List<Book> findByBookCategory(String bookCategory) {
		// TODO Auto-generated method stub
		return bookRepo.findByBookCategory(bookCategory);
	}
	
	@Override
	public List<Book> findByBookAuthorName(String bookAuthorName) {
		// TODO Auto-generated method stub
		return bookRepo.findByBookAuthorName(bookAuthorName);
	}
	
	@Override
	public String findBookStatus(long bookId) {
		Book book=bookRepo.findById(bookId).orElse(null);
		if(book==null) {
			return "Book not found";
			
		}else if(book.getBookQuantity()!=0) {
			return "Availability";
		}else {
			return "Not Available";

			}
	}

}