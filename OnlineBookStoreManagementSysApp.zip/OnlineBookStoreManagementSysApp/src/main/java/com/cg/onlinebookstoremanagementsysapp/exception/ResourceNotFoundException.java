package com.cg.onlinebookstoremanagementsysapp.exception;

public class ResourceNotFoundException extends Exception{
	
	public ResourceNotFoundException(String exMsg) {
		super(exMsg);
	}

}
